#ifndef RAND_HEADER
#define RAND_HEADER

int rand_range(int low, int high);

#endif
